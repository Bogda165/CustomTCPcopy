#include <iostream>
#include <boost/asio.hpp>
#include "MySocket.h"
#include <thread>

using boost::asio::ip::udp;

void receive_message(std::shared_ptr<MySocket> socket) {
    std::vector<uint8_t> vec;
    while(true) {
        if (!socket->receive(vec)) {
            continue;
        };
        std::string message = std::string(vec.begin(), vec.end());
        std::cout << "Received message: " << message << std::endl;
    }
}


void send_message(std::shared_ptr<MySocket> socket) {
    std::string message;
    std::string port_s;
    int port;

    std::cout << "Connection to port: ";
    std::cin >> port_s;
    try {
        port = std::stoi(port_s);
        // send a message with syn keyword
        int _buffer[2] = {1, 0};
        std::vector<uint8_t> vec = {0, 1};
        socket->send_to("127.0.0.1", port, vec, true);
    } catch (...) {
        std::cout << "Error while reading a port" << std::endl;
    }

    //todo change

    while(true) {
        //reading a message
        std::cout << "Enter a message: ";
        std::cin >> message;

        std::vector<uint8_t> vec(message.begin(), message.end());

        socket->send_to("127.0.0.1", port, vec, false);
    }
}

int main() {
    int port1, port2;

    std::cout << "Enter ports: ";
    std::cin >> port1 >> port2;

    boost::asio::io_context io_context;
    auto socket = std::make_shared<MySocket>(port1, port2, "127.0.0.1", std::ref(io_context));

    std::thread recv_thread(receive_message, socket);
    std::thread send_thread(send_message, socket);

    recv_thread.join();
    send_thread.join();

    return 0;
}