//
// Created by User on 21/10/2024.
//

#include "MySocket.h"

const std::string &MySocket::getIp() {
    return ip;
}

int MySocket::getRecvPort() const {
    return recv_port;
}

int MySocket::getSendPort() const {
    return send_port;
}

void MySocket::setIp(const std::string &ip) {
    MySocket::ip = ip;
}

void MySocket::setRecvPort(int recvPort) {
    recv_port = recvPort;
}

void MySocket::setSendPort(int sendPort) {
    send_port = sendPort;
}

MySocket::MySocket(int recv_port, int send_port, std::string ip, boost::asio::io_context& io_context) {
    this->recv_port = recv_port;
    this->send_port = send_port;
    this->ip = ip;
    this->handShake = HandShake::Step1;

    //bindin sockets
    this->send_socket = std::make_shared<udp::socket>(udp::socket(io_context, udp::endpoint(boost::asio::ip::make_address(ip), send_port)));
    this->recv_socket = std::make_shared<udp::socket>(udp::socket(io_context, udp::endpoint(boost::asio::ip::make_address(ip), recv_port)));
}

void MySocket::send_to(std::string send_ip, int port, std::vector<uint8_t>& byte_buffer, bool flag) {
    //add a header
    byte_buffer.insert(byte_buffer.begin(), 0);
    byte_buffer.insert(byte_buffer.begin(), 0);
    std::lock_guard<std::mutex> lock(this->send_socket_m);
    this->send_socket->send_to(boost::asio::buffer(byte_buffer),
                               udp::endpoint(boost::asio::ip::make_address(send_ip), port));
}

bool MySocket::header_handler(std::vector<uint8_t>& buffer, udp::endpoint back_endpoint) {
    int ask = buffer[0] > 0;
    int syn = buffer[1] > 0;
    std::cout << "C";

    if (this->handShake == HandShake::Step1 && ask == 0 && syn == 1) {
        std::cout << "step 1" << std::endl;
        std::lock_guard<std::mutex> lock(this->send_socket_m);
        int _buffer[2] = {1, 1};
        this->send_socket->send_to(boost::asio::buffer(_buffer), back_endpoint);
        // send ask + syn
    }else if (this->handShake == HandShake::Step2 && ask == 1 && syn == 2) {
        std::cout << "step2" << std::endl;
        // send ask
        std::lock_guard<std::mutex> lock(this->send_socket_m);
        int _buffer[2] = {1, 0};
        this->send_socket->send_to(boost::asio::buffer(_buffer), back_endpoint);
    }else if (this->handShake == HandShake::Step3 && ask == 1 && syn == 0) {
        std::cout << "step 3" << std::endl;
        //set connected to true
        this->connected = true;
    }else {
        //can write a buffer
        return false;
    }

    return true;
}

bool MySocket::receive(std::vector<uint8_t>& buffer) {
    char recv_buffer[1024];
    std::lock_guard<std::mutex> lock(this->recv_socket_m);
    udp::endpoint sender_endpoint;
    auto length = this->recv_socket->receive_from(boost::asio::buffer(recv_buffer), sender_endpoint);

    std::vector<uint8_t> header(recv_buffer, recv_buffer + 2);


    //todo get a header
    //now 2 flags are hardcoded as a header as 2 bytes first one is ask second is syn(
    if (header_handler(header, sender_endpoint)) {
        return false;
    };
    //todo delete a header

    buffer = std::vector<uint8_t>(recv_buffer + 2, recv_buffer + length);

    return true;
}

bool MySocket::isConnected() {
    return this->connected;
}